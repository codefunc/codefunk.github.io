import Foundation

extension Snake {
  enum CLI {
    static let (filler, snake, apple) = ("〰️", "🌕", "🍎")
    struct View {
      var board: [[String]]
      let state: State
      
      init(state: State, filler: String = "〰️") {
        self.state = state
        self.board = [[String]](repeating: [String](repeating: filler, count: state.board.width), count: state.board.height)
      }
      
      mutating func render() {
        switch state.status {
        case .menu:
          title(text: "SNAKE", y: 0, xOffset: 2)
          title(text: "'s' to start", y: 3, xOffset: 2)
        case .gameover:
          title(text: "GAME OVER", y: -1, xOffset: 2)
        case .running:
          board[state.apple.y][state.apple.x] = apple
          state.snake.forEach { board[$0.y][$0.x] = snake }
        }
        let output = board.map { $0.joined(separator: "") }.joined(separator: "\n")
        print("\u{1b}cSCORE: \(state.score)\t`q` -- quit, `esc` -- menu\n\(output)")
      }
      
      mutating func title(text: String, y: Int, xOffset: Int = 1) {
        let title = text.compactMap { $0 }
        let y = state.board.height / 2 + y
        var x = state.board.width / 2 - (title.count - 1)
        for letter in title {
          board[y][x] = String(letter) + " "
          x += xOffset
        }
      }
    }
  }
}
