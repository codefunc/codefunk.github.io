import Darwin

struct Ansi {
  var value: String
  init(_ value: String) {
    self.value = value
  }
  func stdout() {
    fputs(self.value, Darwin.stdout)
  }
  func stderr() {
    fputs(self.value, Darwin.stderr)
  }
  static func flush() {
    fflush(__stdoutp)
  }
}

extension Ansi {
  /// DEC Private Mode Set (DECSET) & Reset (DECRST).
  enum Set {
    static let setHQ = { (function: Int) -> Ansi in
      return Ansi("\(Ansi.C1.CSI)?\(function)h")
    }
    
    static let setLQ = { (function: Int) -> Ansi in
      return Ansi("\(Ansi.C1.CSI)?\(function)l")
    }
    
    /// Ps = 4 7  -> Use Normal Screen Buffer
    static func screenBufferNormal() -> Ansi {
      return setHQ(47)
    }
    
    /// Ps = 4 7  -> Use Alternate Screen Buffer
    static func screenBufferAlternate() -> Ansi {
      return setLQ(47)
    }
  }
}

// MARK: - C0 (ASCII and derivatives) -
extension Ansi {
  /// C0 (ASCII and derivatives) also referred to as Single Character
  enum C0 {
    /// ESC CTRL-[
    static let ESC = "\u{1B}"
  }
  
  /// C1 (8-Bit) Control Characters
  enum C1 {
    /// CSI
    static let CSI = Ansi.C0.ESC + "["
  }
}
