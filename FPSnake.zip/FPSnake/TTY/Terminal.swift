import Darwin

public enum Terminal {
  /// Retrieve file descriptor
  fileprivate static func fileDescriptor(_ device: UnsafeMutablePointer<CChar>) -> CInt {
    var descriptor: Int32
    repeat {
      descriptor = open(device, O_RDWR | O_NOCTTY)
    } while descriptor == -1 && errno == EINTR
    return descriptor
  }
  
  // File descriptor for current TTY
  internal static func currentTTY() -> Int32 {
    if let device = ttyname(STDIN_FILENO) {
      return Terminal.fileDescriptor(device)
    } else if let device = ttyname(STDOUT_FILENO) {
      return Terminal.fileDescriptor(device)
    } else if let device = ttyname(STDERR_FILENO) {
      return Terminal.fileDescriptor(device)
    }
    return -1
  }
  
  /// Flush Standard Out
  internal static func flush() {
    fflush(__stdoutp)
  }
}
