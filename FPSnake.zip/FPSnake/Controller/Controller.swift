import Cocoa

extension Snake {
  enum Controller {
    static func dispatchEvents(_ store: inout Store<State, Action>, _ event: NSEvent ) {
      switch event.keyCode {
      case 123: // left arrow
        store.dispatch(.keypress(.left))
      case 124: // right arrow
        store.dispatch(.keypress(.right))
      case 125: // down arrow
        store.dispatch(.keypress(.down))
      case 126: // up arrow
        store.dispatch(.keypress(.up))
      case 53: // esc
        store.dispatch(.menu)
      case 15: // r = reset
        store.dispatch(.reset)
      case 1: // s = start
        store.dispatch(.start)
      case 12: // q = quit
        exit(EXIT_SUCCESS)
      default:
        _ = () // noop
      }
    }
  }
}

class SnakeDelegate: NSResponder, NSApplicationDelegate {
  func applicationDidFinishLaunching(_ notification: Notification) {
    // Add a game loop timer to the current application run loop
    let timer = Timer(fire: Date(), interval: 0.1, repeats: true) { _ in snake.dispatch(.nextframe) }
    RunLoop.current.add(timer, forMode: RunLoop.Mode.default)
    // Add a keydown event listener
    NSEvent.addGlobalMonitorForEvents(
      matching: NSEvent.EventTypeMask.keyDown,
      handler: { event in Snake.Controller.dispatchEvents(&snake, event) }
    )
  }
}
