import Cocoa

Ansi.Set.screenBufferAlternate().stdout()
Ansi.flush()

// Save the current TTY state
var saved_errno: Int32 = errno
let tty = Terminal.currentTTY()
var orig_termios = termios.init()

/// Restore TTY state
func disableRawMode() {
  errno = saved_errno
  tcsetattr(tty, TCSAFLUSH, &orig_termios)
  Ansi.Set.screenBufferNormal().stdout()
  Ansi.flush()
}

/// Enable non-canonical TTY input (disable ICANON and ECHO)
func enableRawMode() {
  tcgetattr(tty, &orig_termios)
  atexit(disableRawMode)
  var raw = orig_termios
  raw.c_lflag &= ~UInt(ICANON | ECHO)
  tcsetattr(tty, TCSAFLUSH, &raw)
}
enableRawMode()

/// Initialize game store
var snake = Snake.initialize()

/// Add game store subscription for UI render
snake.subscribe {
  var view = Snake.CLI.View(state: $0)
  view.render()
}

/// Initialize Main Runloop
let app = NSApplication.shared
let applicationDelegate = SnakeDelegate.init()
app.delegate = applicationDelegate
app.activate(ignoringOtherApps: true)
app.run()
