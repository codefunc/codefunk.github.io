 precedencegroup EuclideanModulo {
  associativity: left
  higherThan: AssignmentPrecedence
 }
 
 /// Euclidean Modulo Operator
 infix operator %%: EuclideanModulo

extension Int {
  /// Euclidean Modulo
  ///
  /// An interesting effect of Euclidean modulo computation is a "wrap around" upon
  /// reaching a certain value **n**, or when crossing **zero**.
  ///
  /// **For example:**
  /// ```
  ///           _______________________________
  ///           |Truncate | Floor   |Euclidean|
  /// ----------|---------|---------|---------|
  /// | -3 % 3  |    0    |    0    |    0    |
  /// | -2 % 3  |   -2    |    1    |    1    |
  /// | -1 % 3  |   -1    |    2    |    2    |
  /// |  0 % 3  |    0    |    0    |    0    |
  /// |  1 % 3  |    1    |    1    |    1    |
  /// |  2 % 3  |    2    |    2    |    2    |
  /// |  3 % 3  |    0    |    0    |    0    |
  /// |---------|---------|---------|---------|
  /// | -3 % -3 |    0    |    0    |    0    |
  /// | -2 % -3 |   -2    |   -2    |    1    |
  /// | -1 % -3 |   -1    |   -1    |    2    |
  /// |  0 % -3 |    0    |    0    |    0    |
  /// |  1 % -3 |    1    |   -2    |    1    |
  /// |  2 % -3 |    2    |   -1    |    2    |
  /// |  3 % -3 |    0    |    0    |    0    |
  /// -----------------------------------------
  /// ```
  func euclideanModulo(_ divisor: Int) -> Int {
    let remainder = self % divisor
    return remainder >= 0 ? remainder : remainder + divisor
  }
  
  /// Euclidean Modulo Operator
  static func %%(lhs: Int, rhs: Int) -> Int {
    return lhs.euclideanModulo(rhs)
  }
}
