struct Store<State, Action> {
  let reducer: Reducer<State, Action>
  var subscribers: [(State) -> Void] = []
  var state: State
  
  init(reducer: Reducer<State, Action>, state: State) {
    self.reducer = reducer
    self.state = state
  }
  
  mutating func dispatch(notify: Bool = true, _ action: Action...) {
    self.state = action.reduce(self.state, self.reducer.reduce)
    if notify { updateSubscribers() }
  }
  
  mutating func subscribe(_ subscriber: @escaping (State) -> Void) {
    self.subscribers.append(subscriber)
    subscriber(self.state)
  }
  
  func updateSubscribers() {
    self.subscribers.forEach { $0(self.state) }
  }
}
