struct Reducer<State, Action> {
  let reduce: (State, Action) -> State
}
