enum Snake {
  // MARK: - KeyPress and Direction vectors -
  enum KeyPress {
    case left
    case right
    case up
    case down
    
    var vector: Coord {
      switch self {
      case .up: return Coord(x: 0, y: -1)
      case .down: return Coord(x: 0, y: 1)
      case .left: return Coord(x: -1, y: 0)
      case .right: return Coord(x: 1, y: 0)
      }
    }
    
    func isNotInverseOf(_ direction: Direction?) -> Bool {
      return Snake.validateKeypress(self, direction)
    }
  }

  // MARK: - Coord (x / y coordinate) -
  struct Coord: Equatable {
    let x: Int
    let y: Int
  }

  // MARK: - Size (width / height) -
  struct Size {
    let width: Int
    let height: Int
    
    func randomCoord() -> Coord {
      return Coord(x: Int.random(in: 0..<width), y: Int.random(in: 0..<height))
    }
  }
  
  enum Status {
    case running
    case menu
    case gameover
  }

  // MARK: - State (game state) -
  struct State {
    let board: Size
    var directions: [KeyPress]
    var snake: [Coord]
    var apple: Coord
    var score: Int
    var status: Status
  }
  
  // MARK: - Action (Effects that alter game state) -
  enum Action {
    case keypress(KeyPress)
    case nextframe
    case reset
    case menu
    case start
  }
}

typealias Direction = Snake.KeyPress

extension Array where Element == Direction {
  var current: Direction? { return self.first }
}

// MARK: - snakeReducer (Application of defined actions on the state) -
extension Snake {
  static let snakeReducer = Reducer<State, Action> { state, action in
    switch action {
    case let .keypress(keypress):
      if keypress.isNotInverseOf(state.directions.current) {
        return addDirection(keypress, state)
      }
    case .nextframe:
      return nextFrame(state)
    case .menu:
      return setStatus(.menu, state)
    case .reset:
      return defaultState
    case .start:
      return setStatus(.running, state)
    }
    return state
  }
}

// MARK: - Game initializer and default state -
extension Snake {
  static let defaultState = State(
    board: Size(width: 30, height: 20),
    directions: [.right],
    snake: [Coord(x: 2, y: 9)],
    apple: Coord(x: 14, y: 9),
    score: 0,
    status: .menu
  )
  
  static func initialize() -> Store<State, Action> {
    return Store(reducer: snakeReducer, state: defaultState)
  }
}

// MARK: - Compute next frame -
extension Snake {
  static var nextFrame: (State) -> (State) {
    return { state in
      if state.status == .menu { return defaultState }
      var result = state
      result.directions = Next.directions(state)
      result.snake = Next.snake(state)
      result.apple = Next.apple(state)
      result.score = Next.score(state)
      if result.snake.isEmpty { result.status = .gameover }
      return result
    }
  }
}

// MARK: - Compute changes for moves, apple, head, snake and score -
extension Snake {
  enum Next {
    static var directions: (State) -> [Direction] {
      return { $0.directions.count > 1 ? Snake.discardDirection($0) : Snake.maintainDirection($0) }
    }
  
    static var apple: (State) -> Coord {
      return { Snake.willCaptureApple($0) ? $0.board.randomCoord() : $0.apple }
    }
    
    static var head: (State) -> Coord {
      return {
        guard let s = $0.snake.first, let d = $0.directions.first?.vector else { return Coord(x: 2, y: 9) }
        return Coord(x: (s.x + d.x) %% $0.board.width, y: (s.y + d.y) %% $0.board.height)
      }
    }
    
    static var snake: (State) -> [Coord] {
      return {
        if Snake.willSelfImpact($0) { return [] }
        if Snake.willCaptureApple($0) { return Snake.grow($0) }
        return Snake.slither($0)
      }
    }
    
    static var score: (State) -> (Int) {
      return { Snake.willCaptureApple($0) ? $0.score + 1 : $0.score }
    }
  }
}

extension Snake {
  static func setStatus(_ status: Status, _ state: State) -> State {
    var result = state
    result.status = status
    return result
  }
  
  static func addDirection(_ direction: KeyPress, _ state: State) -> State {
    var result = state
    result.directions.append(direction)
    return result
  }
}

// MARK: - Snake Transformations-
extension Snake {
  static var grow: (State) -> [Coord] {
    return { [Next.head($0)] + $0.snake }
  }
  
  static var slither: (State) -> [Coord] {
    return { [Next.head($0)] + Array($0.snake.dropLast()) }
  }
  
  static var discardDirection: (State) -> [Direction] {
    return { Array($0.directions.dropFirst()) }
  }
  
  static var maintainDirection: (State) -> [Direction] {
    return { $0.directions }
  }
}

// MARK: - Snake Predicates -
extension Snake {
  static var willCaptureApple: (State) -> Bool {
    return { $0.apple == Next.head($0) }
  }
  
  static var willSelfImpact: (State) -> Bool {
    return { $0.snake.contains(Next.head($0)) }
  }
  
  static var validateKeypress: (KeyPress, Direction?) -> Bool {
    return { keypress, direction in
      guard let direction = direction else { return false }
      return keypress.vector.x + direction.vector.x != 0 || keypress.vector.y + direction.vector.y != 0
    }
  }
}
