﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FPIntro {

  public sealed class Person {
    public readonly string Firstname;
    public readonly string Surname;
    public readonly string Email;

    private Person(string firstname, string surname, string email) {
      Firstname = firstname;
      Surname = surname;
      Email = email;
    }

    public static Func<string, string, string, Person> Create = (firstname, surname, email) => {
      return new Person(firstname, surname, email);
    };

    public override string ToString() {
      return string.Format("Person: [Firstname: {0}, Surname: {1}, Email: {2}]", Firstname, Surname, Email);
    }
  }
}
