﻿using System;
using System.Data;

namespace FPIntro {

  public sealed class Subject {
    public readonly int Id;
    public readonly string Name;

    private Subject(int id, string name) {
      Id = id;
      Name = name;
    }

    public static Func<int, string, Subject> Create = (id, name) => {
      return new Subject(id, name);
    };

    public static Func<IDataReader, Subject> FromSQLReader = reader => {
      return Create(reader.ToInt("id"), reader.ToString("name"));
    };

    public override string ToString() {
      return string.Format("Subject: [Id: {0}, Name: {1}]", Id, Name);
    }
  }
}
