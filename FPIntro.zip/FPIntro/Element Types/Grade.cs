﻿using System;
namespace FPIntro {
  public struct Grade {
    public readonly int ExamId;
    public readonly int StudentId;
    public readonly int SubjectId;
    public readonly int Score;

    private Grade(int examId, int studentId, int subjectId, int score) {
      ExamId = examId;
      StudentId = studentId;
      SubjectId = subjectId;
      Score = score;
    }

    public static Func<int, int, int, int, Grade> Create = (examId, studentId, subjectId, score) => {
      return new Grade(examId, studentId, subjectId, score);
    };
  }
}
