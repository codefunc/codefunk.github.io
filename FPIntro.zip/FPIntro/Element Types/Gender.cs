﻿using System;
namespace FPIntro {
  public enum Gender {
    Male, Female, Unknown
  }

  public static class GenderConvert {
    public static Gender CharToGender(string character) {
      switch (character) {
        case "M": return Gender.Male;
        case "F": return Gender.Female;
        default: return Gender.Unknown;
      }
    }
  }
}
