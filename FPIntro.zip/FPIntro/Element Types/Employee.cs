﻿using System;
using System.Collections.Generic;

namespace FPIntro {
  public sealed class Employee {
    public readonly int Id;
    public readonly string Firstname;
    public readonly string Surname;
    public readonly List<Telephone> Contacts;

    public Employee(int id, string firstname, string surname, List<Telephone> contacts) {
      Id = id;
      Firstname = firstname;
      Surname = surname;
      Contacts = contacts;
    }
  }

  public sealed class Telephone {
    public readonly string Category;
    public readonly int Number;

    public Telephone(string category, int number) {
      Category = category;
      Number = number;
    }

    public override string ToString() {
      return string.Format("Telephone: {{ Category: {0}, Number: {1} }}", Category, Number);
    }
  }
}
