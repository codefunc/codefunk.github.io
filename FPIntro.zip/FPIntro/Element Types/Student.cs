﻿using System;
using System.Data;

namespace FPIntro {
  public sealed class Student {
    public readonly int Id;
    public readonly string Name;
    public readonly string Surname;
    public readonly Gender Gender;
    public readonly DateTime Dob;
    public int Age {
      get { return Dob.DurationInYears(to: DateTime.Today); }
    }

    private Student(int id, string name, string surname, Gender gender, DateTime dob) {
      Id = id;
      Name = name;
      Surname = surname;
      Gender = gender;
      Dob = dob;
    }

    public static Func<int, string, string, Gender, DateTime, Student> Create = (id, name, surname, gender, dob) => {
      return new Student(id, name, surname, gender, dob);
    };

    public static Func<IDataReader, Student> FromSQLReader = reader => {
      return Create(reader.ToInt("id"), reader.ToString("name"), reader.ToString("surname"), GenderConvert.CharToGender(Convert.ToString(reader["gender"])), reader.toDateTime("dob"));
    };

    public override string ToString() {
      return string.Format("Student: [Id: {0}, Name: {1}, Surname: {2}, Gender: {3}, Dob: {4}]", Id, Name, Surname, Gender, Dob);
    }
  }
}
