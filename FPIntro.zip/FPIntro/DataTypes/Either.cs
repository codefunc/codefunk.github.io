﻿using System;

namespace FPIntro {

  #region Either - Functional Extension Methods
  public static partial class ƒ {

    #region Either - Fold
    public static R2 Fold<L, R1, R2>(this Either<L, R1> e, Func<L, R2> leftFn, Func<R1, R2> rightFn) {
      switch (e.state) {
        case EitherState.Right:
          return rightFn(e.right);
        default:
          return leftFn(e.left);
      }
    }
    #endregion

    #region Either - Functor
    public static Either<L, R2> MapR<L, R1, R2>(this Func<R1, R2> fn, Either<L, R1> e) {
      return e.MapR(fn);
    }

    public static Either<L, R2> MapR<L, R1, R2>(this Either<L, R1> e, Func<R1, R2> fn) {
      switch (e.state) {
        case EitherState.Right:
          return Either<L, R2>.Right(fn(e.right));
        default:
          return Either<L, R2>.Left(e.left);
      }
    }

    public static Either<L2, R> MapL<L1, L2, R>(this Func<L1, L2> fn, Either<L1, R> e) {
      return e.MapL(fn);
    }

    public static Either<L2, R> MapL<L1, L2, R>(this Either<L1, R> e, Func<L1, L2> fn) {
      switch (e.state) {
        case EitherState.Right:
          return Either<L2, R>.Right(e.right);
        default:
          return Either<L2, R>.Left(fn(e.left));
      }
    }
    #endregion

    #region Either - Monad
    public static Either<L, R2> FlatMapR<L, R1, R2>(this Either<L, R1> e, Func<R1, Either<L, R2>> fn) {
      switch (e.state) {
        case EitherState.Right:
          return fn(e.right);
        default:
          return Either<L, R2>.Left(e.left);
      }
    }

    public static Either<L, R2> FlatMapR<L, R1, R2>(this Func<R1, Either<L, R2>> fn, Either<L, R1> e) {
      return e.FlatMapR(fn);
    }

    public static Either<L, R2> Bind<L, R1, R2>(this Either<L, R1> e, Func<R1, Either<L, R2>> fn) {
      return e.FlatMapR(fn);
    }
    #endregion

    #region Either - Applicative Functor
    public static Either<L, R2> Apply<L, R1, R2>(this Either<L, R1> e, Either<L, Func<R1, R2>> fn) {
      return fn.FlatMapR(g => e.MapR(x => g(x)));
    }

    public static Either<L, R2> Apply<L, R1, R2>(this Either<L, Func<R1, R2>> fn, Either<L, R1> e) {
      return e.Apply(fn);
    }

    public static Either<L, R> ToEither<L, R>(this R r) {
      return Either<L, R>.Right(r);
    }
    #endregion

    #region Either - Applicative Functor - Lift a function & actions
    public static Either<L, R> LiftA<A, L, R>(this Func<A, R> fn, Either<L, A> a) {
      return fn.MapR(a);
    }

    public static Either<L, R> LiftA<A, B, L, R>(this Func<A, B, R> fn, Either<L, A> a, Either<L, B> b) {
      return fn.Curry().MapR(a).Apply(b);
    }

    public static Either<L, R> LiftA<A, B, C, L, R>(this Func<A, B, C, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c) {
      return fn.Curry().MapR(a).Apply(b).Apply(c);
    }

    public static Either<L, R> LiftA<A, B, C, D, L, R>(this Func<A, B, C, D, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, L, R>(this Func<A, B, C, D, E, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d).Apply(e);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, F, L, R>(this Func<A, B, C, D, E, F, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e, Either<L, F> f) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, F, G, L, R>(this Func<A, B, C, D, E, F, G, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e, Either<L, F> f, Either<L, G> g) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, F, G, H, L, R>(this Func<A, B, C, D, E, F, G, H, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e, Either<L, F> f, Either<L, G> g, Either<L, H> h) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, F, G, H, I, L, R>(this Func<A, B, C, D, E, F, G, H, I, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e, Either<L, F> f, Either<L, G> g, Either<L, H> h, Either<L, I> i) {
      return fn.Curry().ToEither<L, Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, Func<G, Func<H, Func<I, R>>>>>>>>>>().Apply(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i);
    }

    public static Either<L, R> LiftA<A, B, C, D, E, F, G, H, I, J, L, R>(this Func<A, B, C, D, E, F, G, H, I, J, R> fn, Either<L, A> a, Either<L, B> b, Either<L, C> c, Either<L, D> d, Either<L, E> e, Either<L, F> f, Either<L, G> g, Either<L, H> h, Either<L, I> i, Either<L, J> j) {
      return fn.Curry().MapR(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i).Apply(j);
    }
    #endregion

    #region Either - Match
    public static void Match<L, R>(this Either<L, R> e, Action<L> left, Action<R> right) {
      switch (e.state) {
        case EitherState.Right:
          right(e.right);
          return;
        default:
          left(e.left);
          return;
      }
    }
    #endregion

    #region Print
    public static void Print<L, R>(this Either<L, R> e, string title = "") {
      Console.WriteLine("{0} ---> Either[{1}]", title, e.Fold(l => string.Format("Left: {0}", l), r => string.Format("Right: {0}", r)));
    }
    #endregion

  }
  #endregion

  internal enum EitherState {
    Left, Right
  }

  public struct Either<L, R> {
    internal readonly L left;
    internal readonly R right;
    internal readonly EitherState state;

    public bool IsRight => state == EitherState.Right;
    public bool IsLeft => state == EitherState.Left;

    internal Either(R right) {
      this.state = EitherState.Right;
      this.right = right;
      this.left = default(L);
    }

    internal Either(L left) {
      this.state = EitherState.Left;
      this.right = default(R);
      this.left = left;
    }

    public static Either<L, R> Right(R right) {
      return new Either<L, R>(right);
    }

    public static Either<L, R> Left(L left) {
      return new Either<L, R>(left);
    }

    public override string ToString() {
      return string.Format("Either: [{0}: {1}]", this.state, this.Fold<L, R, string>(s => s.ToString(), r => r.ToString()));
    }
  }
}
