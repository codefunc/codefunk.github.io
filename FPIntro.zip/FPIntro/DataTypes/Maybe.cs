﻿using System;

namespace FPIntro {

  #region Maybe - Functional Extension Methods
  public static partial class ƒ {

    #region Maybe - Fold
    public static S2 Fold<S1, S2>(this Maybe<S1> e, Func<S1, S2> someFn) {
      switch (e.state) {
        case MaybeState.Some:
          return someFn(e.some);
        default:
          return default(S2);
      }
    }
    #endregion

    #region Maybe - Functor
    public static Maybe<S2> Map<S1, S2>(this Func<S1, S2> fn, Maybe<S1> e) {
      return e.Map(fn);
    }

    public static Maybe<S2> Map<S1, S2>(this Maybe<S1> e, Func<S1, S2> fn) {
      switch (e.state) {
        case MaybeState.Some:
          return Maybe<S2>.Some(fn(e.some));
        default:
          return Maybe<S2>.None();
      }
    }
    #endregion

    #region Maybe - Monad
    public static Maybe<S2> FlatMap<S1, S2>(this Maybe<S1> e, Func<S1, Maybe<S2>> fn) {
      switch (e.state) {
        case MaybeState.Some:
          return fn(e.some);
        default:
          return Maybe<S2>.None();
      }
    }

    public static Maybe<S2> FlatMap<S1, S2>(this Func<S1, Maybe<S2>> fn, Maybe<S1> e) {
      return e.FlatMap(fn);
    }

    public static Maybe<S2> Bind<S1, S2>(this Maybe<S1> e, Func<S1, Maybe<S2>> fn) {
      return e.FlatMap(fn);
    }
    #endregion

    #region Maybe - Applicative Functor
    public static Maybe<S2> Apply<S1, S2>(this Maybe<S1> e, Maybe<Func<S1, S2>> fn) {
      return fn.FlatMap(g => e.Map(x => g(x)));
    }

    public static Maybe<S2> Apply<S1, S2>(this Maybe<Func<S1, S2>> fn, Maybe<S1> e) {
      return e.Apply(fn);
    }

    public static Maybe<S> ToMaybe<S>(this S s) {
      return Maybe<S>.Some(s);
    }
    #endregion

    #region Maybe - Applicative Functor - Lift a function & actions
    public static Maybe<S> LiftA<A, S>(this Func<A, S> fn, Maybe<A> a) {
      return fn.Map(a);
    }

    public static Maybe<S> LiftA<A, B, S>(this Func<A, B, S> fn, Maybe<A> a, Maybe<B> b) {
      return fn.Curry().Map(a).Apply(b);
    }

    public static Maybe<S> LiftA<A, B, C, S>(this Func<A, B, C, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c) {
      return fn.Curry().Map(a).Apply(b).Apply(c);
    }

    public static Maybe<S> LiftA<A, B, C, D, S>(this Func<A, B, C, D, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, S>(this Func<A, B, C, D, E, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, F, S>(this Func<A, B, C, D, E, F, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e, Maybe<F> f) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, F, G, S>(this Func<A, B, C, D, E, F, G, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e, Maybe<F> f, Maybe<G> g) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, F, G, H, S>(this Func<A, B, C, D, E, F, G, H, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e, Maybe<F> f, Maybe<G> g, Maybe<H> h) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, F, G, H, I, S>(this Func<A, B, C, D, E, F, G, H, I, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e, Maybe<F> f, Maybe<G> g, Maybe<H> h, Maybe<I> i) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i);
    }

    public static Maybe<S> LiftA<A, B, C, D, E, F, G, H, I, J, S>(this Func<A, B, C, D, E, F, G, H, I, J, S> fn, Maybe<A> a, Maybe<B> b, Maybe<C> c, Maybe<D> d, Maybe<E> e, Maybe<F> f, Maybe<G> g, Maybe<H> h, Maybe<I> i, Maybe<J> j) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i).Apply(j);
    }
    #endregion

    #region Maybe - Match
    public static void Match<S>(this Maybe<S> e, Action empty, Action<S> some) {
      switch (e.state) {
        case MaybeState.Some:
          some(e.some);
          return;
        default:
          empty();
          return;
      }
    }
    #endregion

    #region Print
    public static void Print<S>(this Maybe<S> e, string title = "") {
      Console.WriteLine("{0} ---> Maybe[{1}]", title, e.IsNone ? "None" : e.Fold(s => string.Format("Some: {0}", s)));
    }
    #endregion

  }
  #endregion

  internal enum MaybeState {
    None, Some
  }

  public struct Maybe<S> {
    internal readonly S some;
    internal readonly MaybeState state;

    public bool IsSome => state == MaybeState.Some;
    public bool IsNone => state == MaybeState.None;

    internal Maybe(S some) {
      this.state = some == null ? MaybeState.None : MaybeState.Some;
      this.some = some == null ? default(S) : some;
    }

    private Maybe(MaybeState state) {
      this.state = MaybeState.None;
      this.some = default(S);
    }

    public static Maybe<S> Some(S some) {
      return new Maybe<S>(some);
    }

    public static Maybe<S> None() {
      return new Maybe<S>(MaybeState.None);
    }

    public override string ToString() {
      return string.Format("Maybe: [{0}: {1}]", state, IsNone ? "None" : this.Fold(s => s.ToString()));
    }
  }
}
