﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FPIntro {

  #region IEnumerable - Functional Extension Methods
  public static partial class ƒ {

    #region IEnumerable - Fold
    public static U Fold<T, U>(this IEnumerable<T> ts, U identity, Func<U, T, U> fn) {
      var accumulator = identity;
      foreach (T element in ts) {
        accumulator = fn(accumulator, element);
      }
      return accumulator;
    }

    public static Func<IEnumerable<T>, U> Fold<T, U>(U identity, Func<U, T, U> fn) {
      return ts => ƒ.Fold<T, U>(ts, identity, fn);
    }
    #endregion

    #region IEnumerable - Functor
    //public static Func<IEnumerable<T>, IEnumerable<U>> Map<T, U>(this Func<T, U> fn) {
    //  return ts => ts.Map(fn);
    //}

    public static IEnumerable<U> Map<T, U>(this Func<T, U> fn, IEnumerable<T> ts) {
      return ts.Map(fn);
    }

    public static IEnumerable<U> Map<T, U>(this IEnumerable<T> ts, Func<T, U> fn) {
      return ts.Fold(new List<U>(), (a, e) => { a.Add(fn(e)); return a; });
    }
    #endregion

    #region IEnumerable - Flatten
    public static IEnumerable<T> Flatten<T>(this IEnumerable<IEnumerable<T>> ts) {
      return ts.Fold(new List<T>(), (a, e) => { if (e != null) { a.AddRange(e); }; return a; });
    }
    #endregion

    #region IEnumerable - Monad
    public static IEnumerable<U> FlatMap<T, U>(this Func<T, IEnumerable<U>> fn, IEnumerable<T> ts) {
      return ts.FlatMap(fn);
    }

    public static IEnumerable<U> FlatMap<T, U>(this IEnumerable<T> ts, Func<T, IEnumerable<U>> fn) {
      return ts.Map(fn).Flatten();
    }

    public static IEnumerable<U> Bind<T, U>(this IEnumerable<T> ts, Func<T, IEnumerable<U>> fn) {
      return ts.FlatMap(fn);
    }
    #endregion

    #region IEnumerable - Filterable
    public static IEnumerable<T> Filter<T>(this Func<T, bool> fn, IEnumerable<T> ts) {
      return ts.Filter(fn);
    }

    public static IEnumerable<T> Filter<T>(this IEnumerable<T> ts, Func<T, bool> fn) {
      return ts.Fold(new List<T>(), (a, e) => { if (fn(e)) { a.Add(e); } return a; });
    }
    #endregion

    #region IEnumerable - Applicative Functor
    public static IEnumerable<U> Apply<T, U>(this IEnumerable<T> ts, IEnumerable<Func<T, U>> fn) {
      return fn.FlatMap(g => ts.Map(x => g(x)));
    }

    public static IEnumerable<U> Apply<T, U>(this IEnumerable<Func<T, U>> fn, IEnumerable<T> ts) {
      return ts.Apply(fn);
    }

    public static IEnumerable<T> ToList<T>(this T t) {
      return new List<T> { t };
    }
    #endregion

    #region IEnumerable - Applicative Functor - Lift a function & actions
    public static IEnumerable<R> LiftA<A, R>(this Func<A, R> fn, IEnumerable<A> a) {
      return fn.Map(a);
    }

    public static IEnumerable<R> LiftA<A, B, R>(this Func<A, B, R> fn, IEnumerable<A> a, IEnumerable<B> b) {
      return fn.Curry().Map(a).Apply(b);
    }

    public static IEnumerable<R> LiftA<A, B, C, R>(this Func<A, B, C, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c) {
      return fn.Curry().Map(a).Apply(b).Apply(c);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, R>(this Func<A, B, C, D, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, R>(this Func<A, B, C, D, E, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, F, R>(this Func<A, B, C, D, E, F, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e, IEnumerable<F> f) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, F, G, R>(this Func<A, B, C, D, E, F, G, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e, IEnumerable<F> f, IEnumerable<G> g) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, F, G, H, R>(this Func<A, B, C, D, E, F, G, H, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e, IEnumerable<F> f, IEnumerable<G> g, IEnumerable<H> h) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, F, G, H, I, R>(this Func<A, B, C, D, E, F, G, H, I, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e, IEnumerable<F> f, IEnumerable<G> g, IEnumerable<H> h, IEnumerable<I> i) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i);
    }

    public static IEnumerable<R> LiftA<A, B, C, D, E, F, G, H, I, J, R>(this Func<A, B, C, D, E, F, G, H, I, J, R> fn, IEnumerable<A> a, IEnumerable<B> b, IEnumerable<C> c, IEnumerable<D> d, IEnumerable<E> e, IEnumerable<F> f, IEnumerable<G> g, IEnumerable<H> h, IEnumerable<I> i, IEnumerable<J> j) {
      return fn.Curry().Map(a).Apply(b).Apply(c).Apply(d).Apply(e).Apply(f).Apply(g).Apply(h).Apply(i).Apply(j);
    }
    #endregion

    #region IEnumerable - Join Recreated
    public static List<A> AddReturn<A>(this List<A> source, A element) {
      source.Add(element);
      return source;
    }


    public static IEnumerable<R> JoinAP<A, B, C, R>(this IEnumerable<A> outer, IEnumerable<B> inner, Func<A, C> outerKey, Func<B, C> innerKey, Func<A, B, R> result) {
      Func<A, B, List<R>> f = (a, b) => outerKey(a).Equals(innerKey(b)) ? new List<R> { result(a, b) } : null;
      return outer.Map(f.Curry()).Apply(inner).Flatten();
    }

    public static IEnumerable<R> JoinAP<A, B, R>(this IEnumerable<A> outer, IEnumerable<B> inner, Func<A, B, bool> predicate, Func<A, B, R> result) {
      Func<A, B, List<R>> f = (a, b) => predicate(a, b) ? new List<R> { result(a, b) } : null;
      return outer.Map(f.Curry()).Apply(inner).Flatten();
    }

    #endregion

    #region IEnumerable - Collection Helpers (Equivalent to Take, TakeWhile & Skip, SkipWhile)
    public static IEnumerable<A> Take2<A>(this IEnumerable<A> source, int quantity) {
      return source.Fold((new List<A>(), 0), (a, e) => (a.Item2 < quantity) ? (a.Item1.AddReturn(e), ++a.Item2) : (a.Item1, ++a.Item2)).Item1;
    }

    public static IEnumerable<A> Skip2<A>(this IEnumerable<A> source, int quantity) {
      return source.Fold((new List<A>(), 0), (a, e) => (a.Item2 >= quantity) ? (a.Item1.AddReturn(e), ++a.Item2) : (a.Item1, ++a.Item2)).Item1;
    }
    #endregion

    #region Print
    public static void Print<T>(this IEnumerable<T> ts, string title = "", string delimeter = "") {
      Console.WriteLine("{0} ---> List {1}", title, ts.Fold($"{{{delimeter}", (a, e) => a + string.Format("{0}, {1}", e, delimeter)).DropLast(delimeter.Length==0 ? 2 : 3) + $"{delimeter}}}");
    }

    public static void Print<T>(this IEnumerable<IEnumerable<T>> ts, string title = "", string delimeter = "") {
      Console.WriteLine("{0} ---> List {1}", title, ts.Fold("{", (a, e) => a + delimeter + "{" + e.Fold("", (ai, ei) => ai + string.Format("{0}, ", ei)).DropLast(2) + "}, ").DropLast(2) + delimeter + "}");
    }
    #endregion

  }
  #endregion

}
