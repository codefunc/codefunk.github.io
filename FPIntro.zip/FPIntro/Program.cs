﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace FPIntro {
  class MainClass { 
    public static void Main(string[] args) {

      // ********************************************************************************
      //
      // Applicative Form validation example using 3 differnt FP data types
      //
      // ********************************************************************************
      string fname = "john";
      string sname = "parker";
      string email = "john.parkeremail.com";

      Console.WriteLine("\n{0} Applicative form validation using IEnumerable, returns empty List if failed", new string('-', 10));
      Person.Create.LiftA(
        fname.Length > 5 ? new List<string> { fname } : new List<string> { },
        sname.Length > 5 ? new List<string> { sname } : new List<string> { },
        email.Contains("@") ? new List<string> { email } : new List<string> { }
      ).Print("IEnumerable Input Form Failure");

      Console.WriteLine("\n{0} Applicative form validation using Maybe; returns `None` if failed", new string('-', 10));
      Person.Create.LiftA(
        fname.Length > 5 ? Maybe<string>.Some(fname) : Maybe<string>.None(),
        sname.Length > 5 ? Maybe<string>.Some(sname) : Maybe<string>.None(),
        email.Contains("@") ? Maybe<string>.Some(email) : Maybe<string>.None()
      ).Print("Maybe Input Form Failure");

      Console.WriteLine("\n{0} Applicative form validation using Either; returns 1st failure text", new string('-', 10));
      Person.Create.LiftA(
        fname.Length > 5 ? Either<string, string>.Right(fname) : Either<string, string>.Left("Invalid Firstname"),
        sname.Length > 5 ? Either<string, string>.Right(sname) : Either<string, string>.Left("Invalid Surname"),
        email.Contains("@") ? Either<string, string>.Right(email) : Either<string, string>.Left("Invalid Email")
      ).Print("Either Input Form Failure");

      Console.WriteLine("\n{0} Concurrent Applicative form validation using Validation; returns all the failures that occurred", new string('-', 10));
      Person.Create.LiftA(
        fname.Length > 5 ? Validation<string, string>.Right(fname) : Validation<string, string>.Left("Invalid Firstname"),
        sname.Length > 5 ? Validation<string, string>.Right(sname) : Validation<string, string>.Left("Invalid Surname"),
        email.Contains("@") ? Validation<string, string>.Right(email) : Validation<string, string>.Left("Invalid Email")
      ).Print("Validation Input Form Failure");

      // ********************************************************************************
      //
      // Re-implementation example of FP combinators for processing IEnumerable elements
      //
      // ********************************************************************************
      Console.WriteLine("\n{0} Substring characters from an input string", new string('-', 10));
      "a quick movement of the enemy"
        .FlatMap(x => new List<char> { x }) // converts string to List<char>
        .Skip2(8) // skip over the 1st 8 characters
        .Take2(8) // take the next 8 characters
        .Fold("", (a, e) => a + e) // turn the List<char> back into a string
        .Print();

      // ********************************************************************************
      //
      // IEnumerable `FlatMap` used in conjunction with `Map` to reach into a tiered
      // data structure and retrieve a property and avoid a nested result. 
      //
      // FlatMap is the same as Linq's `SelectMany`
      // Map is the same Linq's `Select`
      //
      // Reimplemetation is to demonstrate the relation between the algebras, and also
      // to provide alternative method signatures, where the transform function is
      // positioned before the IEnumberable parameter
      //
      // ********************************************************************************
      var employees = new List<Employee> {
        new Employee(1, "jack", "sprat", new List<Telephone> {
          new Telephone("mobile", 123),
          new Telephone("landline", 456),
          new Telephone("office", 789) 
        }),
        new Employee(2, "snow", "white", new List<Telephone> {
          new Telephone("mobile", 223),
          new Telephone("landline", 556),
          new Telephone("office", 889)
        }),
        new Employee(3, "tom", "jerry", new List<Telephone> {
          new Telephone("mobile", 332),
          new Telephone("landline", 665),
          new Telephone("office", 998)
        })
      };

      Console.WriteLine("\n{0} Retrieve a property from a tiered data structure", new string('-', 10));
      var phonenums = employees.FlatMap(e => e.Contacts.Map(c => c.Number));
      phonenums.Print("Telephone Numbers", "");


      // ********************************************************************************
      //
      // Maybe Data Type
      // Is used for scenarios where values can either be `Some` value or `None`
      // Simply said it's a monadic version of Nullable
      //
      // ********************************************************************************

      // Assign `Some` value to age
      // Safely calculate the year of birth; these statements will not generate 
      // Exceptions if age is `None` 
      // --------------------------------------------------------------------------------
      Console.WriteLine("\n{0} Safely Map over something that has `Some`", new string('-', 10));
      var age = Maybe<int>.Some(23);
      var year = age.Map(v => 2019 - v);
      year.Print("Year of birth");

      Console.WriteLine("\n{0} Safely Map over something that has `None`", new string('-', 10));
      var age2 = Maybe<int>.None();
      var year2 = age2.Map(v => 2019 - v);
      year2.Print("Year of birth");


      // ********************************************************************************
      //
      // Either DataType
      // Is used scenarios where we need to track values for 1 of 2 possible outcomes.
      //
      // For example: 
      //    With SQL it's important to know what caused something to fail; 
      //    Either's `Left property` is more typically used to track failures, whereas 
      //    the `Right` property tracks success.
      //
      // ********************************************************************************

      // Setup SQLite Database 
      // --------------------------------------------------------------------------------
      Console.WriteLine("\n{0} Setup SQLite Database", new string('-', 10));
      var newDB = SQL.CreateSQLiteDB(Config.dbFilePath);
      SQL
        .ConnectToSQLite(Config.dbConnection)
        .Bind(SQL.BindSQL(script: Script.initialise))
        .Bind(SQL.ExecuteNonQuery());


      // SELECT * FROM Students;
      // --------------------------------------------------------------------------------
      Console.WriteLine("\n{0} SELECT * FROM Students;", new string('-', 10));
      SQL
        .ConnectToSQLite(Config.dbConnection)
        .Bind(SQL.BindSQL(script: Script.Select.sqlGetAllStudents))
        .Bind(SQL.ExecuteReader(transform: Student.FromSQLReader))
        .Match(
          left: Console.WriteLine,
          right: xs => xs.ForEach(Console.WriteLine)
        );


      // SELECT * FROM Students WHERE id = @StudentID;
      // --------------------------------------------------------------------------------
      Console.WriteLine("\n{0} SELECT * FROM Students WHERE id = @StudentID;", new string('-', 10));
      SQL
        .ConnectToSQLite(Config.dbConnection)
        .Bind(SQL.Parameters(p => p.Add(new SQLiteParameter("@StudentID", 2))))
        .Bind(SQL.BindSQL(script: Script.Select.sqlGetStudentsById))
        .Bind(SQL.ExecuteReader(transform: Student.FromSQLReader))
        .Match(
          left: Console.WriteLine,
          right: xs => xs.ForEach(Console.WriteLine)
        );


      // ********************************************************************************
      //
      // Recreating Linq's Join using FP algebras
      //
      // ********************************************************************************
      var students = new List<Student> {
        Student.Create(1, "Jack", "Sprat", Gender.Male, new DateTime(1990, 12, 1)),
        Student.Create(2, "Mary", "Contrary", Gender.Female, new DateTime(1992, 2, 13)),
        Student.Create(3, "Snow", "White", Gender.Female, new DateTime(1994, 6, 7))
      };

      var grades = new List<Grade> {
        Grade.Create(201801, 1 ,3, 75),
        Grade.Create(201801, 1, 4, 82),
        Grade.Create(201801, 2, 3, 93),
        Grade.Create(201801, 2, 1, 78),
        Grade.Create(201801, 3, 3, 73),
        Grade.Create(201801, 3, 2, 67)
      };

      var subjects = new List<Subject> {
        Subject.Create(1, "Biology"),
        Subject.Create(2, "Economics"),
        Subject.Create(3, "Mathematics"),
        Subject.Create(4, "Science")
      };

      Console.WriteLine("\n{0} Join 3 IEnumerables with FP", new string('-', 10));
      students
        .JoinAP(inner: grades, predicate: (a, b) => a.Id == b.StudentId, result: (a, b) => new { a.Id, a.Name, a.Surname, a.Dob, b.SubjectId, b.Score })
        .JoinAP(inner: subjects, predicate: (a, b) => a.Id == b.Id, result: (a, b) => new { a.Id, a.Name, a.Surname, a.SubjectId, a.Score, a.Dob, subjectId = b.Id, subjectTitle = b.Name })
        .Print("students.JoinAP(grades).JoinAP(subjects)", "\n");

    }
  }
}



