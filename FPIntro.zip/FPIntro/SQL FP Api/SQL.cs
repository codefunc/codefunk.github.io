﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Data.SqlClient;

namespace FPIntro {
  using DBInstance = Tuple<IDbConnection, IDbCommand>;
  public static class SQL {

    #region New SQLite Database Instance
    /// <summary>
    /// Creates a new SQLite Database file at the specified path.
    /// </summary>
    public static Either<string, bool> CreateSQLiteDB(string dbFilePath) {
      return ƒ.TryEitherLog(() => {
        dbFilePath.DeleteFileIfExists().Match(
          right: (success) => { }, // NOP
          left: (message) => { throw new Exception(message); }
        );
        SQLiteConnection.CreateFile(dbFilePath);
        return Either<string, bool>.Right(true);
      });
    }
    #endregion

    #region Connectivity
    /// <summary>
    /// Connect to SQLite instance using a specified connectionString.
    /// </summary>
    public static Either<string, DBInstance> ConnectToSQLite(string connectionString) {
      return ƒ.TryEitherLog(() => {
        var connection = new SQLiteConnection(connectionString);
        connection.Open();
        var command = connection.CreateCommand();
        return Either<string, DBInstance>.Right(new DBInstance(connection, command));
      });
    }

    /// <summary>
    /// Connect to SqlClient instance using a specified connectionString.
    /// </summary>
    public static Either<string, DBInstance> ConnectToSqlClient(string connectionString) {
      return ƒ.TryEitherLog(() => {
        var connection = new SqlConnection(connectionString);
        connection.Open();
        var command = connection.CreateCommand();
        return Either<string, DBInstance>.Right(new DBInstance(connection, command));
      });
    }
    #endregion

    #region Execute Queries
    /// <summary>
    /// Executes the non query.
    /// </summary>
    public static Func<DBInstance, Either<string, int>> ExecuteNonQuery() {
      return db => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          var result = command.ExecuteNonQuery();
          db.DisposeAndClose();
          return Either<string, int>.Right(result);
        });
      };
    }

    /// <summary>
    /// Executes the reader.
    /// </summary>
    public static Func<DBInstance, Either<string, List<T>>> ExecuteReader<T>(Func<IDataReader, T> transform) {
      return db => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          var reader = command.ExecuteReader();
          var result = reader.ToType(transform);
          reader.Dispose();
          db.DisposeAndClose();
          return Either<string, List<T>>.Right(result);
        });
      };
    }

    /// <summary>
    /// Executes the scalar.
    /// </summary>
    public static Func<DBInstance, Either<string, T>> ExecuteScalar<T>(Func<object, T> transform) {
      return db => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          var result = transform(command.ExecuteScalar());
          db.DisposeAndClose();
          return Either <string, T>.Right(result);
        });
      };
    }
    #endregion

    #region Bind SQL or Stored Procedure
    public static Func<DBInstance, Either<string, DBInstance>> BindSQL(string script) {
      return db => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          command.CommandText = script;
          return Either<string, DBInstance>.Right(new DBInstance(connection, command));
        });
      };
    }

    public static Func<DBInstance, Either<string, DBInstance>> BindProcedure(string script) {
      return db => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          command.CommandText = script;
          command.CommandType = CommandType.StoredProcedure;
          return Either<string, DBInstance>.Right(new DBInstance(connection, command));
        });
      };
    }

    #endregion

    #region Sql Parameters tied to Values
    public static Func<DBInstance, Either<string, DBInstance>> Parameters(Action<IDataParameterCollection> fn) {
      return (db) => {
        return ƒ.TryEitherLog(() => {
          var (connection, command) = db;
          fn(command.Parameters);
          return Either<string, DBInstance>.Right(new DBInstance(connection, command));
        });
      };
    }
    #endregion

    #region SqlExtension Methods
    public static void DisposeAndClose(this (IDbConnection connection, IDbCommand command) db) {
      db.command.Dispose();
      db.connection.Close();
    }

    public static void DisposeAndClose(this DBInstance db) {
      var (connection, command) = db;
      command.Dispose();
      connection.Close();
    }

    public static List<T> ToType<T>(this IDataReader reader, Func<IDataReader, T> fn) {
      var result = new List<T>();
      while (reader.Read()) {
        result.Add(fn(reader));
      }
      return result;
    }
    #endregion

  }
}
