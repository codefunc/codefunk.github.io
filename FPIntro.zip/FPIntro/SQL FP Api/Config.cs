﻿using System;
namespace FPIntro {
  public static class Config {
    public static string dbFilePath = "Test.db";
    public static string dbConnection = string.Format("URI=file:{0}", Config.dbFilePath);
  }
}
