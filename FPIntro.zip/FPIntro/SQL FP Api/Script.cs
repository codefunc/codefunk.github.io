﻿using System.Collections.Generic;

namespace FPIntro {
  public static class Script {
    public static class Select {
      public static readonly string sqlGetStudentsById = @"
SELECT * 
FROM Students 
WHERE id = @StudentID;
      ".Trim();

      public static readonly string sqlGetAllStudents = @"
SELECT * 
FROM Students;
      ".Trim();
    }

    public static class Create {
      public static string students = @"
CREATE TABLE IF NOT EXISTS Students(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  surname TEXT NOT NULL,
  gender CHAR(1) NULL,
  dob INTEGER NULL
);
      ".Trim();
    }

    public static class Insert {
      public static string students = @"
INSERT INTO Students (name, surname, gender, dob) VALUES('Johnny','Walker','M', 1062540000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Lucas','Radebe','M', 1031004000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Charles','Glass','M', 1062540000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Sally','Williams','F', 1031004000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Mary','Smith','F',  1062540000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Jenny','Lopez','F', 1062540000);
INSERT INTO Students (name, surname, gender, dob) VALUES('Daniel','Steele','M', 1031004000);
     ".Trim();
    }

    public static string initialise = new List<string> { Create.students, Insert.students }.Fold("", (a, e) => a + e + "\n");
  }
}
