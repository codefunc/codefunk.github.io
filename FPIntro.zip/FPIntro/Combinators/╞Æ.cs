﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace FPIntro {

  // macOS: alt-f
  // Windows: ctrl-alt f
  public static partial class ƒ {

    #region Lift to Lambda Form
    public static Func<A> Lambda<A>(Func<A> fn) => fn;
    public static Func<A, B> Lambda<A, B>(Func<A, B> fn) => fn;
    public static Func<A, B, C> Lambda<A, B, C>(Func<A, B, C> fn) => fn;
    public static Func<A, B, C, D> Lambda<A, B, C, D>(Func<A, B, C, D> fn) => fn;
    public static Func<A, B, C, D, E> Lambda<A, B, C, D, E>(Func<A, B, C, D, E> fn) => fn;
    public static Func<A, B, C, D, E, F> Lambda<A, B, C, D, E, F>(Func<A, B, C, D, E, F> fn) => fn;
    public static Func<A, B, C, D, E, F, G> Lambda<A, B, C, D, E, F, G>(Func<A, B, C, D, E, F, G> fn) => fn;
    public static Func<A, B, C, D, E, F, G, H> Lambda<A, B, C, D, E, F, G, H>(Func<A, B, C, D, E, F, G, H> fn) => fn;
    #endregion

    #region Currying
    public static Func<A, Func<B, C>> Curry<A, B, C>(this Func<A, B, C> fn) => a => b => fn(a, b);
    public static Func<A, Func<B, Func<C, D>>> Curry<A, B, C, D>(this Func<A, B, C, D> fn) => a => b => c => fn(a, b, c);
    public static Func<A, Func<B, Func<C, Func<D, E>>>> Curry<A, B, C, D, E>(this Func<A, B, C, D, E> fn) => a => b => c => d => fn(a, b, c, d);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, F>>>>> Curry<A, B, C, D, E, F>(this Func<A, B, C, D, E, F> fn) => a => b => c => d => e => fn(a, b, c, d, e);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, G>>>>>> Curry<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn) => a => b => c => d => e => f => fn(a, b, c, d, e, f);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, Func<G, H>>>>>>> Curry<A, B, C, D, E, F, G, H>(this Func<A, B, C, D, E, F, G, H> fn) => a => b => c => d => e => f => g => fn(a, b, c, d, e, f, g);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, Func<G, Func<H, I>>>>>>>> Curry<A, B, C, D, E, F, G, H, I>(this Func<A, B, C, D, E, F, G, H, I> fn) => a => b => c => d => e => f => g => h => fn(a, b, c, d, e, f, g, h);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, Func<G, Func<H, Func<I, J>>>>>>>>> Curry<A, B, C, D, E, F, G, H, I, J>(this Func<A, B, C, D, E, F, G, H, I, J> fn) => a => b => c => d => e => f => g => h => i => fn(a, b, c, d, e, f, g, h, i);
    public static Func<A, Func<B, Func<C, Func<D, Func<E, Func<F, Func<G, Func<H, Func<I, Func<J, K>>>>>>>>>> Curry<A, B, C, D, E, F, G, H, I, J, K>(this Func<A, B, C, D, E, F, G, H, I, J, K> fn) => a => b => c => d => e => f => g => h => i => j => fn(a, b, c, d, e, f, g, h, i, j);
    #endregion

    #region Partial Application
    public static Func<B, C> Partial<A, B, C>(this Func<A, B, C> fn, A a) => b => fn(a, b);
    public static Func<B, C, D> Partial<A, B, C, D>(this Func<A, B, C, D> fn, A a) => (b, c) => fn(a, b, c);
    public static Func<C, D> Partial<A, B, C, D>(this Func<A, B, C, D> fn, A a, B b) => c => fn(a, b, c);
    public static Func<B, C, D, E> Partial<A, B, C, D, E>(this Func<A, B, C, D, E> fn, A a) => (b, c, d) => fn(a, b, c, d);
    public static Func<C, D, E> Partial<A, B, C, D, E>(this Func<A, B, C, D, E> fn, A a, B b) => (c, d) => fn(a, b, c, d);
    public static Func<D, E> Partial<A, B, C, D, E>(this Func<A, B, C, D, E> fn, A a, B b, C c) => d => fn(a, b, c, d);
    public static Func<B, C, D, E, F> Partial<A, B, C, D, E, F>(this Func<A, B, C, D, E, F> fn, A a) => (b, c, d, e) => fn(a, b, c, d, e);
    public static Func<C, D, E, F> Partial<A, B, C, D, E, F>(this Func<A, B, C, D, E, F> fn, A a, B b) => (c, d, e) => fn(a, b, c, d, e);
    public static Func<D, E, F> Partial<A, B, C, D, E, F>(this Func<A, B, C, D, E, F> fn, A a, B b, C c) => (d, e) => fn(a, b, c, d, e);
    public static Func<E, F> Partial<A, B, C, D, E, F>(this Func<A, B, C, D, E, F> fn, A a, B b, C c, D d) => e => fn(a, b, c, d, e);
    public static Func<B, C, D, E, F, G> Partial<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn, A a) => (b, c, d, e, f) => fn(a, b, c, d, e, f);
    public static Func<C, D, E, F, G> Partial<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn, A a, B b) => (c, d, e, f) => fn(a, b, c, d, e, f);
    public static Func<D, E, F, G> Partial<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn, A a, B b, C c) => (d, e, f) => fn(a, b, c, d, e, f);
    public static Func<E, F, G> Partial<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn, A a, B b, C c, D d) => (e, f) => fn(a, b, c, d, e, f);
    public static Func<F, G> Partial<A, B, C, D, E, F, G>(this Func<A, B, C, D, E, F, G> fn, A a, B b, C c, D d, E e) => f => fn(a, b, c, d, e, f);
    #endregion

    #region Composition
    public static Func<A, C> Compose<A, B, C>(this Func<A, B> lhs, Func<B, C> rhs) => a => rhs(lhs(a));
    #endregion

    #region Basic Combinators
    public static T Id<T>(T t) => t;
    public static Func<U, T> Const<T, U>(T t) => u => t;
    public static Func<T, T> Id<T>() {
      return t => t;
    }
    #endregion

    #region Tuple Predicates
    public static bool And<A, B>(this (A, B) tuple, A a, B b) where A : IEquatable<A> where B : IEquatable<B> {
      return tuple.Item1.Equals(a) && tuple.Item2.Equals(b);
    }

    public static bool Or<A, B>(this (A, B) tuple, A a, B b) where A : IEquatable<A> where B : IEquatable<B> {
      return tuple.Item1.Equals(a) || tuple.Item2.Equals(b);
    }

    public static bool First<A, B>(this (A, B) tuple, A a) where A : IEquatable<A> where B : IEquatable<B> {
      return tuple.Item1.Equals(a);
    }

    public static bool Second<A, B>(this (A, B) tuple, B b) where A : IEquatable<A> where B : IEquatable<B> {
      return tuple.Item2.Equals(b);
    }
    #endregion

    #region Tuple splat
    public static R Apply<A, R>(this ValueTuple<A> t, Func<A, R> f) => f(t.Item1);
    public static R Apply<A, B, R>(this ValueTuple<A, B> t, Func<A, B, R> f) => f(t.Item1, t.Item2);
    public static R Apply<A, B, C, R>(this ValueTuple<A, B, C> t, Func<A, B, C, R> f) => f(t.Item1, t.Item2, t.Item3);
    public static R Apply<A, B, C, D, R>(this ValueTuple<A, B, C, D> t, Func<A, B, C, D, R> f) => f(t.Item1, t.Item2, t.Item3, t.Item4);
    public static R Apply<A, B, C, D, E, R>(this ValueTuple<A, B, C, D, E> t, Func<A, B, C, D, E, R> f) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5);
    public static R Apply<A, B, C, D, E, F, R>(this ValueTuple<A, B, C, D, E, F> t, Func<A, B, C, D, E, F, R> f) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5, t.Item6);
    public static R Apply<A, B, C, D, E, F, G, R>(this ValueTuple<A, B, C, D, E, F, G> t, Func<A, B, C, D, E, F, G, R> f) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5, t.Item6, t.Item7);

    public static Func<(A, B), R> ToTuple<A, B, R>(this Func<A, B, R> f) => (t) => f(t.Item1, t.Item2);
    public static Func<(A, B, C), R> ToTuple<A, B, C, R>(this Func<A, B, C, R> f) => (t) => f(t.Item1, t.Item2, t.Item3);
    public static Func<(A, B, C, D), R> ToTuple<A, B, C, D, R>(this Func<A, B, C, D, R> f) => (t) => f(t.Item1, t.Item2, t.Item3, t.Item4);
    public static Func<(A, B, C, D, E), R> ToTuple<A, B, C, D, E, R>(this Func<A, B, C, D, E, R> f) => (t) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5);
    public static Func<(A, B, C, D, E, F), R> ToTuple<A, B, C, D, E, F, R>(this Func<A, B, C, D, E, F, R> f) => (t) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5, t.Item6);
    public static Func<(A, B, C, D, E, F, G), R> ToTuple<A, B, C, D, E, F, G, R>(this Func<A, B, C, D, E, F, G, R> f) => (t) => f(t.Item1, t.Item2, t.Item3, t.Item4, t.Item5, t.Item6, t.Item7);
    #endregion

    #region String Methods
    public static string DropLast(this string input, int quantity) {
      if (input.Count() - quantity < 0) { return input; }
      return input.Substring(0, input.Count() - quantity);
    }

    public static string DropFirst(this string input, int quantity) {
      if (input.Count() - quantity < 0) { return input; }
      return input.Substring(quantity);
    }
    #endregion

    #region Type Methods
    public static string FuncString(this Type type) {
      var result = type.ToString();
      var substitutions = new Dictionary<string, string> {
          {"System.", ""},
          {",", ", "},
          {"[", "<"},
          {"]", ">"},
          {"Int32", "int"},
          {"String", "string"},
          {"Double", "double"},
          {"Float", "float"},
      };

      var regex = new Regex(String.Join("|", substitutions.Keys.Select(k => Regex.Escape(k))));
      result = regex.Replace(result, m => substitutions[m.Value]);
      result = Regex.Replace(result, @"Func`\d", "Func");
      return result;
    }
    #endregion

    #region Print
    public static void Print(this string t) {
      Console.WriteLine(t);
    }
    #endregion

    #region Measure Execution Time in milliseconds
    public static void Measure(string title, Action f) {
      Stopwatch stopwatch = Stopwatch.StartNew();
      f();
      stopwatch.Stop();
      Console.WriteLine("{0} : {1}ms", title, stopwatch.ElapsedMilliseconds);
    }
    #endregion

    #region Exception Handling / Logging
    public static string LogDefault(Exception e) {
      return string.Format("message: {0}\ntrace: {1}\n", e.Message, e.StackTrace);
    }

    public static Either<string, T> TryEitherLog<T>(Func<Either<string, T>> tryFunc) {
      try {
        return tryFunc();
      } catch (Exception e) {
        return Either<string, T>.Left(LogDefault(e));
      }
    }
    #endregion

    #region With Reference Combinator
    public static A With<A>(this A a, Action<A> f) {
      f(a);
      return a;
    }
    #endregion

    #region File / Directory
    public static Either<string, bool> DeleteFileIfExists(this string filePath) {
      return TryEitherLog(() => {
        var result = false;
        if (File.Exists(filePath)) {
          File.Delete(filePath);
          result = true;
        }
        return Either<string, bool>.Right(result);
      });
    }

    public static Either<string, bool> CreateDirectory(this string filePath) {
      return TryEitherLog(() => {
        var result = false;
        if (!Directory.Exists(filePath)) {
          Directory.CreateDirectory(filePath);
          result = true;
        }
        return Either<string, bool>.Right(result); ;
      });
    }
    #endregion

    #region IDataRecord Conversion
    public static int ToInt(this IDataReader record, string sqlColumnName) {
      return Convert.ToInt32(record[sqlColumnName]);
    }

    public static long ToLong(this IDataReader record, string sqlColumnName) {
      return Convert.ToInt64(record[sqlColumnName]);
    }

    public static string ToString(this IDataReader record, string sqlColumnName) {
      return Convert.ToString(record[sqlColumnName]);
    }

    public static bool ToBoolean(this IDataReader record, string sqlColumnName) {
      return Convert.ToBoolean(record[sqlColumnName]);
    }

    public static double ToSingle(this IDataReader record, string sqlColumnName) {
      return Convert.ToSingle(record[sqlColumnName]);
    }

    public static double ToDouble(this IDataReader record, string sqlColumnName) {
      return Convert.ToDouble(record[sqlColumnName]);
    }

    public static DateTime toDateTime(this IDataReader record, string sqlColumnName) {
      return ((long)Convert.ToInt32(record[sqlColumnName])).UnixTimeSecondsToDateTime();
    }
    #endregion

    #region DateTime Extension Methods
    public static int DurationInYears(this DateTime from, DateTime to) {
      var years = to.Year - from.Year;
      return (from > to.AddYears(-years)) ? years-- : years;
    }

    public static long ToUnixTimeSeconds(this DateTime from) {
      var timeOffset = new DateTimeOffset(from);
      return timeOffset.ToUnixTimeSeconds();
    }

    public static DateTime UnixTimeSecondsToDateTime(this long from) {
      return DateTimeOffset.FromUnixTimeSeconds(from).DateTime.ToLocalTime();
    }
    #endregion

  }
}
