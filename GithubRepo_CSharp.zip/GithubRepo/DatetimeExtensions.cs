﻿using System;
namespace GithubRepo
{
  public static class DateTimeExtensions
  {
    public static string ToDays(this DateTime from, DateTime to) {
      return string.Format("{0}d", (to - from).Days);
    }
  }
}
