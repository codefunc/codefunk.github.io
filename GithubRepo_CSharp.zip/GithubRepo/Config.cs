﻿using System;
namespace GithubRepo
{
  public static class Config
  {
    public static string user = "google";
    public static string baseAPI = "https://api.github.com/users/";
    public static Func<string, string> reposFor = (account) => baseAPI + account + "/repos";
    public static string httpUserAgent = "";
  }
}