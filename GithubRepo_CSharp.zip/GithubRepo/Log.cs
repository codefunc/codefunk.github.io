﻿using System;
using System.Net;
namespace GithubRepo
{
  public static class Log
  {
    public static string Default(Exception e)
    {
      return string.Format("message: {0}\ntrace: {1}\n", e.Message, e.StackTrace);
    }

    public static string Web(WebException e)
    {
      try {
        return Log.Default(e) + string.Format("response: {0}\nStatus: {1}\nResponseUri: {2}\n", e.Response, e.Status, e.Response.ResponseUri);
      } catch {
        return Log.Default(e);
      }
    }
  }
}
