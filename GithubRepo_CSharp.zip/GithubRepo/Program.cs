﻿using System;
using System.Collections.Generic;
using static LanguageExt.Prelude;

namespace GithubRepo
{
  class MainClass
  {
    public static void Main(string[] args)
    {
      var current = Current.Instance;

      //current.environment = GithubMock.Success;

      // View Binding: Code to bind the results in our view controller
      current.environment.github.fetchRepos(e => {
        e.Match(gl => gl.ForEach(Console.WriteLine), ge => Console.WriteLine("We crashed: {0}", ge));
      });

      // Pause processing on the current thread to allow async processes to complete
      // Simulated run loop; not required once a view and viewcontroller is used.
      System.Threading.Thread.Sleep(100000);
    }
  }
}
