﻿using System;
using System.IO;
using System.Net;
using LanguageExt;
using static LanguageExt.Prelude;

namespace GithubRepo
{
  public sealed class URLSession
  {
    private readonly Either<string, string> URL;
    private URLSession(string url)
    {
      URL = Right(url);
    }

    public static URLSession Of(string url)
    {
      return new URLSession(url);
    }

    public Either<string, string> Download() {
      return this.URL
                 .Bind(EscapeURL)
                 .Bind(ConnectToURL)
                 .Bind(ValidateConnection)
                 .Bind(DecodeStream);
    }

    private static Either<string, string> EscapeURL(string url) {
      try {
        return Right(Uri.EscapeUriString(url));
      } catch (Exception e) {
        return Left(Log.Default(e));
      }
    }

    private static Either<string, HttpWebRequest> ConnectToURL(string url) {
      try {
        return Right(WebRequest.Create(url) as HttpWebRequest);
      } catch (WebException e) {
        return Left(Log.Web(e));
      }
    }

    private static Either<string, HttpWebResponse> ValidateConnection(HttpWebRequest http) {
      try {
        http.UserAgent = Config.httpUserAgent;
        var response = http.GetResponse() as HttpWebResponse;
        if (response.StatusCode == HttpStatusCode.OK) {
          return Right(response);
        } else {
          return Left(string.Format("Unexpected HttpStatusCode: {0}", response.StatusCode));
        }
      } catch (WebException e) {
        return Left(Log.Web(e));
      }
    }

    private static Either<string, string> DecodeStream(HttpWebResponse http) {
      try {
        return Right((new StreamReader(http.GetResponseStream())).ReadToEnd());
      } catch (WebException e) {
        return Left(Log.Web(e));
      }
    }
  }
}