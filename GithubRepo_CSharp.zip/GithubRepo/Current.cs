﻿using System;
namespace GithubRepo
{
  public sealed class Current
  {
    public Environment environment = new Environment();

    private Current() { }
    public static Current Instance { get { return Internal.instance; } }
    private class Internal
    {
      private Internal() { }
      internal static readonly Current instance = new Current();
    }
  }
}
