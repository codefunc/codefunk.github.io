﻿using System;
using System.Collections.Generic;
using LanguageExt;
using static LanguageExt.Prelude;

namespace GithubRepo
{
  public static class GithubMock
  {
    private static void FetchSuccess(Action<Either<string, List<Github.Repository>>> fetchRepos)
    {
      fetchRepos(Right(new List<Github.Repository>(){
        Github.Repository.Of(
          false,
          "Mock Repo 1",
          "https://github.com/mock/mockrepo1",
          "mockrepo1",
          DateTime.Parse("2018/09/06 7:21")),
        Github.Repository.Of(
          false,
          "Mock Repo 2",
          "https://github.com/mock/mockrepo2",
          "mockrepo2",
          DateTime.Parse("2018/09/04 9:45"))
        })
      );
    }

    private static void FetchFail(Action<Either<string, List<Github.Repository>>> fetchRepos)
    {
      fetchRepos(Left("Mock Failure"));
    }

    public static Environment Success = new Environment(new Github(GithubMock.FetchSuccess), DateTime.Parse("2018/09/06 12:00"));
    public static Environment Fail = new Environment(new Github(GithubMock.FetchFail));
  }
}
