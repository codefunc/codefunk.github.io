﻿using System;
using Newtonsoft.Json.Linq;

namespace GithubRepo
{
  public static class JTokenExtensionMethods
  {
    private static JToken GetJToken(this JToken token, string key)
    {
      return GetJToken<JToken>(token, key, null);
    }

    public static string String(this JToken token, string key)
    {
      return token.GetJToken(key, "");
    }

    public static int Int(this JToken token, string key)
    {
      return token.GetJToken(key, -1);
    }

    public static bool Bool(this JToken token, string key)
    {
      return token.GetJToken(key, false);
    }

    public static double Double(this JToken token, string key)
    {
      return token.GetJToken(key, -1d);
    }

    public static DateTime Date(this JToken token, string key)
    {
      try {
        return DateTime.Parse(token[key].ToString());
      } catch (Exception e) {
        Console.WriteLine(e.StackTrace);
        return DateTime.Parse("1997/01/01 12:00");
      }
    }

    private static T GetJToken<T>(this JToken token, string key, T failValue)
    {
      try {
        return token[key].ToObject<T>();
      } catch {
        return failValue;
      }
    }
  }
}
