﻿using System;
namespace GithubRepo
{
  public sealed class Environment
  {
    public Github github = new Github();
    public DateTime date = DateTime.Now;

    public Environment() { }

    public Environment(Github github, DateTime? date = null) {
      this.github = github;
      this.date = date ?? DateTime.Now;
    }
  }
}
