﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using LanguageExt;
using static LanguageExt.Prelude;

namespace GithubRepo
{
  public sealed class Github
  {
    public class Repository {
      public readonly bool archived;
      public readonly string description;
      public readonly string htmlURL;
      public readonly string name;
      public readonly DateTime pushedAt;

      private Repository(bool archived, string description, string htmlURL, string name, DateTime pushedAt) {
        this.archived = archived;
        this.description = description;
        this.htmlURL = htmlURL;
        this.name = name;
        this.pushedAt = pushedAt;
      }

      private Repository() {}

      public static Repository Of(bool archived, string description, string htmlURL, string name, DateTime pushedAt) {
        return new Repository(archived, description, htmlURL, name, pushedAt);
      }

      override public string ToString()
      {
        return string.Format("archived: {0}, description: {1}, htmlURL: {2}, name: {3}, pushedAt: {4}", archived, description, htmlURL, name, pushedAt.ToDays(Current.Instance.environment.date));
      }
    }

    public static Either<string, List<Repository>> Parse(string json)
    {
      try {
        var tokens = JArray.Parse(json);
        var repositories = new List<Repository>();
        foreach (JToken t in tokens) {
          repositories.Add(Repository.Of(
            t.Bool("archived"),
            t.String("description"),
            t.String("htmlUrl"),
            t.String("name"),
            t.Date("pushed_at")));
        }
        return Right(repositories);
      } catch (Exception e) {
        return Left(Log.Default(e));
      }
    }

    public Action<Action<Either<string, List<Repository>>>> fetchRepos = FetchRepos;

    public Github() { }

    public Github(Action<Action<Either<string, List<Repository>>>> fetchRepos) {
      this.fetchRepos = fetchRepos;
    }

    public static void FetchRepos(Action<Either<string, List<Repository>>> fetchRepos) {
      DataTask(Config.reposFor(Config.user), fetchRepos);
    }

    public static void DataTask(string url, Action<Either<string, List<Repository>>> completionHandler) {
      Task.Run(() => { 
        return URLSession.Of(url).Download().Bind(Github.Parse);
      }).ContinueWith(t => {
        completionHandler(t.Result);
      });
    }
  }
}
