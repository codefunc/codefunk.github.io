import AppKit
import PlaygroundSupport
import GithubDI

// ============================================================================================================
//
// Github struct comprosing of the fields we need; Decodable conformance handles the JSON decode
//
// ============================================================================================================
public struct Github {
  public struct Repository: Decodable {
    public var archived: Bool
    public var description: String?
    public var htmlUrl: URL
    public var name: String
    public var pushedAt: Date?
  }
  public var fetchRepos: (@escaping (Result<[Github.Repository], Error>) -> Void) -> ()
  public init(fetchRepos: @escaping (@escaping ((Result<[Github.Repository], Error>) -> Void)) -> () = fetchRepos(onComplete:)) {
    self.fetchRepos = fetchRepos
  }
}

// ============================================================================================================
//
// Github - Default fetchRepos Implementation & Async Github Repository task (including JSON decoding)
//
// ============================================================================================================
extension Github {
  public static func fetchRepos(onComplete completionHandler: (@escaping (Result<[Repository], Error>) -> Void)) {
    dataTask(Config.user, completionHandler: completionHandler)
  }

  private static func dataTask<T: Decodable>(_ user: String, completionHandler: (@escaping (Result<T, Error>) -> Void)) {
    let request = URLRequest(url: Config.reposFor(user))
    URLSession.shared.dataTask(with: request) { data, urlResponse, error in
      do {
        if let error = error {
          throw error
        } else if let data = data {
          completionHandler(.success(try Config.decoder.decode(T.self, from: data)))
        } else {
          fatalError()
        }
      } catch let failError {
        completionHandler(.failure(failError))
      }
      }.resume()
  }
}

// ============================================================================================================
//
// TableView Column configuration helpers
//
// ============================================================================================================
extension Github {
  public static let columns = [
    Table.Column(title: "Name", id: "name", width: 200),
    Table.Column(title: "Last Update", id: "pushedAt", width: 100),
    Table.Column(title: "Archived", id: "archived", width: 50),
    Table.Column(title: "Description", id: "description", width: 400),
    Table.Column(title: "URL", id: "htmlUrl", width: 200),
    ]
  
  public static func tableCell(for id: String, repos: [Repository], row: Int, to: Date) -> NSView? {
    switch id {
    case "name": return Table.cell(repos[row].name)
    case "description": return Table.cell(repos[row].description ?? "")
    case "pushedAt": return Table.cell(Table.formatDuration(from: repos[row].pushedAt, to: to))
    case "htmlUrl": return Table.cell(repos[row].htmlUrl.absoluteString)
    case "archived": return Table.cell(repos[row].archived.description)
    default: return nil
    }
  }
}

// ============================================================================================================
//
// Sort helper for data fetched from Github
//
// ============================================================================================================
extension Array where Element == Github.Repository {
  public func sortByPushedAt() -> [Github.Repository] {
    return self.sorted(by: {
      guard let lhs = $0.pushedAt, let rhs = $1.pushedAt else { return false }
      return lhs > rhs
    })
  } 
}
// ============================================================================================================
//
// GithubProtocol - Constructor Dependency Method(s) and Github struct conformance (implement fetchRepos)
//
// ============================================================================================================
public protocol GithubProtocol {
  func fetchRepos(onComplete completionHandler: (@escaping (Result<[Github.Repository], Error>) -> Void))
}

extension Github: GithubProtocol {
  public func fetchRepos(onComplete completionHandler: @escaping ((Result<[Github.Repository], Error>) -> Void)) {
    return self.fetchRepos(completionHandler)
  }
}

// ============================================================================================================
//
// Github Repository TableView
//
// ============================================================================================================
public class RepoTableView: NSTableView, NSTableViewDelegate, NSTableViewDataSource {
  public var repos: [Github.Repository] = [] { didSet { self.reloadData() } }
  public var date: () -> Date
  
  public init(frame frameRect: NSRect, injectedDate: @escaping () -> Date) {
    self.date = injectedDate
    super.init(frame: frameRect)
    layoutSubViews()
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  func layoutSubViews() {
    _ = with(self) { t in
      t.autoresizingMask = .width
      Github.columns.forEach { t.addTableColumn($0.tableColumn()) }
      t.dataSource = self
      t.delegate = self
    }
  }
  
  public func numberOfRows(in tableView: NSTableView) -> Int {
    return self.repos.count
  }
  
  public func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
    guard let id = (tableColumn?.identifier)?.rawValue else { return nil }
    return Github.tableCell(for: id, repos: repos, row: row, to: self.date())
  }
}

// ============================================================================================================
//
// Github Repository ViewController: Default Constructor(init) and properties related to DI
//
// ============================================================================================================
public class RepoViewController: NSViewController {
  let github: GithubProtocol // Callback depedency
  let date: () -> Date // Date dependency
  var tableView: RepoTableView? = nil
  
  // Default constructor with dependencies, including default production values
  public init(date: @escaping () -> Date = Date.init, github: GithubProtocol = Github()) {
    self.github = github
    self.date = date
    super.init(nibName: nil, bundle: nil)
  }
  
  public required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  override public func loadView() {
    self.view = NSView(frame: NSRect(origin: .zero, size: Config.size))
    let container = NSScrollView(frame: self.view.bounds)
    self.tableView = RepoTableView(frame: self.view.bounds, injectedDate: self.date)
    container.documentView = self.tableView
    self.view.addSubview(container)
  }
  
  override public func viewDidLoad() {
    super.viewDidLoad()
    asyncLoadRepositories()
  }
}

// ============================================================================================================
//
// Async Loading of Github Repositories
//
// ============================================================================================================
extension RepoViewController {
  func asyncLoadRepositories() {
    self.github.fetchRepos { [weak self] result in
      DispatchQueue.main.async {
        switch result {
        case let .success(repos):
          self?.tableView?.repos = repos.sortByPushedAt()
        case let .failure(error):
          NSAlert.warning("Failure", error, "OK").runModal()
        }
      }
    }
  }
}

// ============================================================================================================
//
// Examples of Test Mocking: Offline Success / Failure with fixed parameters (easy validation and screenshots)
//
// ============================================================================================================

public struct GithubMockSuccess: GithubProtocol {
  public func fetchRepos(onComplete completionHandler: @escaping ((Result<[Github.Repository], Error>) -> Void)) {
    completionHandler(
      .success([
        Github.Repository(
          archived: false,
          description: "Mock Repo 1",
          htmlUrl: URL(string: "https://github.com/mock/mockrepo1")!,
          name: "mockrepo1",
          pushedAt: Date.fromString(using: "2018/09/06 7:21")!),
        Github.Repository(
          archived: false,
          description: "Mock Repo 2",
          htmlUrl: URL(string: "https://github.com/mock/mockrepo3")!,
          name: "mockrepo2",
          pushedAt: Date.fromString(using: "2018/09/04 9:45")!)
        ]
      )
    )
  }
}

public struct GithubMockFailure: GithubProtocol {
  public func fetchRepos(onComplete completionHandler: @escaping ((Result<[Github.Repository], Error>) -> Void)) {
    completionHandler(
      .failure(NSError.init(
        domain: "za.co.mybbDI",
        code: 1,
        userInfo: [NSLocalizedDescriptionKey: "Mock Failure"]))
    )
  }
}

// ============================================================================================================
//
// Create instance of ViewController and present in Playground
//
// ============================================================================================================
//let viewController = RepoViewController(date: { Date.fromString(using: "2018/09/06 12:00")! }, github: GithubMockSuccess())
//let viewController = RepoViewController(date: { Date.fromString(using: "2018/09/06 12:00")! }, github: GithubMockFailure())
let viewController = RepoViewController()
PlaygroundPage.current.liveView = viewController
