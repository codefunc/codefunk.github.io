import Foundation

public enum Config {
  public static let size = NSSize(width: 1024, height: 640)
  public static let user = "google"
  public static let baseAPI = "https://api.github.com/users/"
  public static var reposFor: (String) -> URL = { user in URL(string: baseAPI + user + "/repos")! }
  public static let dateFormat = with(DateFormatter()) {
    $0.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZZZZZ"
    $0.locale = Locale(identifier: "en_ZA_POSIX")
    $0.timeZone = TimeZone(secondsFromGMT: 2 * 60 * 60)
  }
  public static let decoder = with(JSONDecoder()) {
    $0.dateDecodingStrategy = .formatted(dateFormat)
    $0.keyDecodingStrategy = .convertFromSnakeCase
  }
}
