import Cocoa

public enum Table {
  public struct Column {
    public let title: String
    public let id: String
    public let width: CGFloat
    
    public init(title: String, id: String, width: CGFloat) {
      self.title = title
      self.id = id
      self.width = width
    }
    
    public func tableColumn() -> NSTableColumn {
      return with(NSTableColumn()) {
        $0.headerCell.title = self.title
        $0.identifier = NSUserInterfaceItemIdentifier(self.id)
        $0.width = self.width
      }
    }
  }
  
  public static func cell(_ id: String) -> NSTextField {
    return with(NSTextField(labelWithString: id)) {
      $0.isBordered = false
    }
  }
  
  public static func formatDuration(from: Date?, to: Date) -> String {
    let dateFormat = with(DateComponentsFormatter()) {
      $0.allowedUnits = [.day, .hour, .minute, .second]
      $0.maximumUnitCount = 1
      $0.unitsStyle = .abbreviated
    }
    guard let from = from else { return "" }
    return dateFormat.string(from: from, to: to) ?? ""
  }
}
