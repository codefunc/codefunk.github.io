import Foundation

public extension Date {
  public static func fromString(using formattedString: String) -> Date? {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy/MM/dd HH:mm"
    return formatter.date(from: formattedString)
  }
}
