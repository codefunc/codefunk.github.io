public func with<A: AnyObject>(_ a: A, _ f: (A) throws -> Void) rethrows -> A {
  try f(a)
  return a
}

public func with<A>(_ a: inout A, _ f: (inout A) throws -> Void) rethrows {
  try f(&a)
}
