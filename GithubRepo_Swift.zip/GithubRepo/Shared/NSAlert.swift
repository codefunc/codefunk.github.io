import Cocoa

public extension NSAlert {
  public static func warning(_ text: String, _ error: Error, _ buttonText: String) -> NSAlert {
    return with(NSAlert()) {
      $0.messageText = text
      $0.informativeText = error.localizedDescription
      $0.alertStyle = .warning
      $0.addButton(withTitle: buttonText)
    }
  }
}
